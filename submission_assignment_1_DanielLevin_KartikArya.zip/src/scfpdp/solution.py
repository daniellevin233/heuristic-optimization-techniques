import copy
from pathlib import Path
from typing import Any, Callable

from pymhlib.solution import Solution

from src.scfpdp.instance import SCFPDPInstance


class Route:
    def __init__(self, instance: SCFPDPInstance, delta_callback: Callable[[int, int], None], use_delta_eval: bool = False) -> None:
        self.instance = instance
        self.delta_callback = delta_callback
        self.use_delta_eval = use_delta_eval
        self.route: list[int] = []
        self.distance: int = 0
        self.served_requests: list[int] = []

    def __repr__(self):
        return f"Served requests: {{{', '.join(str(i) for i in self.served_requests)}}} along the route: {["depot"] + self.route + ["depot"]} (distance={self.distance:.2f}; capacity={self.get_carried_capacity()}/{self.instance.C})"

    def __len__(self) -> int:
        return len(self.route)

    def _get_distance_between(self, loc1: int | None, loc2: int | None) -> int:
        """
        Get distance between two locations. None represents depot.
        loc1 and loc2 are location indices as they appear in self.route.
        """
        if loc1 is None:
            idx1 = 0  # depot
        else:
            idx1 = loc1 + 1  # location indices are offset by 1 in distance_matrix

        if loc2 is None:
            idx2 = 0  # depot
        else:
            idx2 = loc2 + 1

        return self.instance.distance_matrix[idx1][idx2]

    def recompute_route_distance(self) -> None:
        """Full recalculation of route distance. Used for verification and initialization."""
        old_distance = self.distance

        if len(self.route) == 0:
            self.distance = 0
            self.delta_callback(self.distance, old_distance)
            return

        from_depot_distance = self.instance.distance_matrix[0][self.route[0] + 1]
        to_depot_distance = self.instance.distance_matrix[0][self.route[-1] + 1]
        route_distance = 0
        for i, source_location in enumerate(self.route[:-1]):
            target_location = self.route[i + 1]
            route_distance += self.instance.distance_matrix[source_location + 1][target_location + 1]
        self.distance = from_depot_distance + route_distance + to_depot_distance
        self.delta_callback(self.distance, old_distance)

    def _calculate_insertion_delta(self, location_idx: int, at: int) -> int:
        """
        Calculate distance delta for inserting location_idx at position at.
        Must be called BEFORE the actual insertion.

        Returns the change in distance: (new_edges_distance - old_edges_distance)
        """
        # Get neighbors before and after insertion position
        prev_loc = None if at == 0 else self.route[at - 1]
        next_loc = None if at >= len(self.route) else self.route[at]

        # Old edge: prev -> next
        old_distance = self._get_distance_between(prev_loc, next_loc)

        # New edges: prev -> location_idx -> next
        new_distance = (self._get_distance_between(prev_loc, location_idx) +
                       self._get_distance_between(location_idx, next_loc))

        return new_distance - old_distance

    def _calculate_removal_delta(self, at: int) -> int:
        """
        Calculate distance delta for removing location at position at.
        Must be called BEFORE the actual removal.

        Returns the change in distance: (new_edge_distance - old_edges_distance)
        """
        location_idx = self.route[at]

        # Get neighbors
        prev_loc = None if at == 0 else self.route[at - 1]
        next_loc = None if at >= len(self.route) - 1 else self.route[at + 1]

        # Old edges: prev -> location -> next
        old_distance = (self._get_distance_between(prev_loc, location_idx) +
                       self._get_distance_between(location_idx, next_loc))

        # New edge: prev -> next
        new_distance = self._get_distance_between(prev_loc, next_loc)

        return new_distance - old_distance

    def insert_location(self, location_idx: int, at: int) -> None:
        if location_idx in self.route:
            raise ValueError(f"Request {location_idx} is already in the route")
        if location_idx in self.served_requests:
            raise ValueError(f"Request {location_idx} is already served")

        self.route.insert(at, location_idx)
        # serve the request if it's a pickup index
        if location_idx < self.instance.n:
            self.served_requests.append(location_idx)

    def serve_request(self, request_id: int, pickup_at: int, dropoff_distance_from_pickup: int) -> None:
        if pickup_at > len(self.route):
            raise ValueError(f"Pickup insertion index is out of range: {pickup_at}; route length: {len(self.route)}")
        if dropoff_distance_from_pickup <= 0:
            raise ValueError("Dropoff must be at least one position to the right from the pickup")
        dropoff_at = pickup_at + dropoff_distance_from_pickup
        if dropoff_at > len(self.route) + 1:
            raise ValueError(f"Dropoff insertion index is out of range: {dropoff_at}; route length: {len(self.route)}")

        if self.use_delta_eval:
            # TSP-like delta evaluation: calculate only affected edges
            old_distance = self.distance
            pickup_delta = self._calculate_insertion_delta(request_id, pickup_at)

            # Insert pickup (modifies route)
            self.insert_location(request_id, pickup_at)

            # Calculate dropoff delta after pickup insertion
            dropoff_delta = self._calculate_insertion_delta(request_id + self.instance.n, dropoff_at)

            # Insert dropoff
            self.insert_location(request_id + self.instance.n, dropoff_at)
            self.check()

            # Update distance incrementally
            self.distance = old_distance + pickup_delta + dropoff_delta
            self.delta_callback(self.distance, old_distance)
        else:
            # Full recalculation
            self.insert_location(request_id, pickup_at)
            self.insert_location(request_id + self.instance.n, dropoff_at)
            self.check()
            self.recompute_route_distance()

    def can_take_request(self, request_id: int, at_position: int) -> bool:
        return self.get_capacity_at_position(at_position) + self.instance.demands[request_id] <= self.instance.C

    def get_carried_capacity(self) -> int:
        return self.get_capacity_at_position(len(self.route))

    def get_capacity_at_position(self, position: int) -> int:
        """
        Calculate vehicle capacity at a specific position in the route given what it has picked up so far
            but has not dropped off yet
        """
        capacity = 0
        for location_idx in self.route[:position]:
            if location_idx < self.instance.n:  # pickup
                capacity += self.instance.demands[location_idx]
            else:  # dropoff
                capacity -= self.instance.demands[location_idx - self.instance.n]
        return capacity

    def _check_capacity_constraint_at_position(self, position: int) -> int:
        capacity = 0
        for location_idx in self.route[:position]:
            if location_idx < self.instance.n:  # pickup
                capacity += self.instance.demands[location_idx]
                if capacity > self.instance.C:
                    raise ValueError(f"Capacity constraint violation at {location_idx} is violated")
            else:  # dropoff
                capacity -= self.instance.demands[location_idx - self.instance.n]
        return capacity

    def check_capacity_constraint(self) -> None:
        total_capacity = self._check_capacity_constraint_at_position(len(self.route))
        if total_capacity != 0:
            raise ValueError(f"Capacity constraint is violated with total capacity {total_capacity} instead of 0")

    def n_served_requests(self) -> int:
        return len(self.served_requests)

    def check(self) -> None:
        if len(self.route) % 2 !=  0:
            raise ValueError(f"Route of odd length: {len(self.route)}; the length must be even")

        for request_id in self.served_requests:
            pickup_idx = request_id
            dropoff_idx = request_id + self.instance.n

            if pickup_idx not in self.route:
                raise ValueError(f"Request {request_id} is marked as served but pickup location {pickup_idx} not in route")

            if dropoff_idx not in self.route:
                raise ValueError(f"Request {request_id} is marked as served but dropoff location {dropoff_idx} not in route")

            pickup_pos = self.route.index(pickup_idx)
            dropoff_pos = self.route.index(dropoff_idx)

            if pickup_pos >= dropoff_pos:
                raise ValueError(f"Request {request_id}: dropoff at position {dropoff_pos} must come after pickup at position {pickup_pos}")

        self.check_capacity_constraint()

    def swap_locations(self, location_a, location_b) -> None:
        self.route[location_a], self.route[location_b] = self.route[location_b], self.route[location_a]
        self.check()
        self.recompute_route_distance()

    def move_from_to(self, move_from: int, move_to: int) -> None:
        moved_value = self.route.pop(move_from)
        self.route.insert(move_to, moved_value)
        self.check()
        self.recompute_route_distance()

    def relocate_request_to(self, request_id: int, route_to: 'Route', pos_to: int, dropoff_distance_from_pickup: int) -> None:
        self.remove_request(request_id)
        route_to.serve_request(request_id, pos_to, dropoff_distance_from_pickup)

    def remove_request(self, request_id: int) -> None:
        """Remove both pickup and dropoff locations for a request from this route."""
        pickup_idx = request_id
        dropoff_idx = request_id + self.instance.n

        pickup_pos = self.route.index(pickup_idx)
        dropoff_pos = self.route.index(dropoff_idx)

        if self.use_delta_eval:
            # TSP-like delta evaluation: calculate only affected edges
            old_distance = self.distance

            # Calculate deltas before removal (remove in reverse order)
            # Remove dropoff first (higher index)
            dropoff_delta = self._calculate_removal_delta(dropoff_pos)
            self.route.pop(dropoff_pos)

            # Then remove pickup (index hasn't shifted because we removed from the end)
            pickup_delta = self._calculate_removal_delta(pickup_pos)
            self.route.pop(pickup_pos)

            if request_id in self.served_requests:
                self.served_requests.remove(request_id)

            self.check()

            # Update distance incrementally
            self.distance = old_distance + pickup_delta + dropoff_delta
            self.delta_callback(self.distance, old_distance)
        else:
            # Full recalculation
            for idx in sorted([pickup_pos, dropoff_pos], reverse=True):
                self.route.pop(idx)

            if request_id in self.served_requests:
                self.served_requests.remove(request_id)

            self.check()
            self.recompute_route_distance()



class SCFPDPSolution(Solution):

    to_maximize = False

    def __init__(self, inst: SCFPDPInstance, use_delta_eval: bool = False) -> None:
        super().__init__(inst)
        self.use_delta_eval = use_delta_eval
        self.routes: list[Route] = [Route(inst, self.delta_evaluation, use_delta_eval) for _ in range(inst.n_K)]
        self.inst = inst  # this is overridden simply to help compiler with type hinting

        self._cached_total_distance: int = 0
        self._cached_sum_of_squares: int = 0

    def __repr__(self):
        is_valid = True
        error = 'N/A'
        try:
            self.check()
        except ValueError as e:
            is_valid = False
            error = e.args[0]
        objective_message = f'Objective: {self.calc_objective():.2f}'
        lines = [f"SCFPDPSolution({objective_message if is_valid else f'Invalid solution: "{error}";{objective_message}'})"]
        for vehicle_i, route in enumerate(self.routes):
            lines.append(f"  Vehicle {vehicle_i}: {route}")
        total_requests = sum(route.n_served_requests() for route in self.routes)
        lines.append(f"  Total requests served: {total_requests}/{self.inst.n} (min required: {self.inst.gamma})")
        return '\n'.join(lines)

    def copy_from(self, other: 'SCFPDPSolution'):
        self.routes = copy.deepcopy(other.routes)
        if self.use_delta_eval:
            self._cached_total_distance = other._cached_total_distance
            self._cached_sum_of_squares = other._cached_sum_of_squares

            # Reconnect callbacks to this solution's method
            for route in self.routes:
                route.delta_callback = self.delta_evaluation

    def copy(self):
        sol = SCFPDPSolution(self.inst, self.use_delta_eval)
        sol.copy_from(self)
        return sol

    def invalidate(self):
        if self.use_delta_eval:
            self._cached_total_distance = 0.0
            self._cached_sum_of_squares = 0.0

    def delta_evaluation(self, new_distance: int, old_distance: int) -> None:
        if self.use_delta_eval:
            self._cached_total_distance += (new_distance - old_distance)
            self._cached_sum_of_squares += (new_distance ** 2 - old_distance ** 2)

    def calc_objective(self) -> float:
        if self.use_delta_eval:
            if self._cached_sum_of_squares == 0:
                return 0
            jain = self._cached_total_distance / (self.inst.n_K * self._cached_sum_of_squares)
            return self._cached_total_distance + self.inst.rho * (1 - jain)

        total_distance, sum_of_squares = 0, 0
        for route in self.routes:
            total_distance += route.distance
            sum_of_squares += route.distance**2
        if sum_of_squares == 0:
            return 0
        jain = total_distance / (self.inst.n_K * sum_of_squares)
        return total_distance + self.inst.rho * (1 - jain)

    def initialize(self, k):
        from src.algorithms.construction_heuristics import GreedyConstructionHeuristic
        self.invalidate()
        GreedyConstructionHeuristic(self).construct()

    def check(self):
        super().check()

        # number of routes is not greater than number of vehicles (not sure this check is required)
        if len(self.routes) > self.inst.n_K:
            raise ValueError(f"Expected up to {self.inst.n_K} routes but got {len(self.routes)}")

        all_served_requests = set()
        for route_i, route in enumerate(self.routes):
            try:
                route.check()
            except ValueError as e:
                raise ValueError(f"Route {route_i} is invalid: {e}") from e

            for request_id in route.served_requests:
                if request_id in all_served_requests:
                    raise ValueError(f"Request {request_id} appears in multiple routes")
                all_served_requests.add(request_id)

        n_total_served_requests = len(all_served_requests)
        if n_total_served_requests < self.inst.gamma:
            raise ValueError(f"Not enough requests served: {n_total_served_requests} < {self.inst.gamma} (gamma)")
        return None

    def get_all_served_requests(self) -> set[int]:
        return set().union(*[r.served_requests for r in self.routes])

    def is_complete(self) -> bool:
        # self.check()
        return len(self.get_all_served_requests()) == self.inst.gamma

    def random_move_delta_eval(self, neighborhood: "Neighborhood") -> tuple[Any, float]:
        move, test_solution = neighborhood.generate_random_neighbor(self)
        if test_solution is None:  # no valid solution - let SA iterate further by skipping this infeasible solution
            return None, float('inf')
        current_obj = self.calc_objective()
        new_obj = test_solution.calc_objective()
        delta = new_obj - current_obj
        return move, delta

    def apply_neighborhood_move(self, move):
        move.move(self)

    def write_to_file(self, algorithm: str) -> None:
        instance_file = Path(self.inst.file_name)
        instance_name = instance_file.stem

        current = Path.cwd()
        project_root = current
        while project_root != project_root.parent:
            if (project_root / "instances").exists():
                break
            project_root = project_root.parent

        solutions_dir = project_root / "solutions"
        solutions_dir.mkdir(parents=True, exist_ok=True)

        output_file = solutions_dir / f"{instance_name}_{algorithm}_{self.calc_objective():.2f}.txt"
        
        with open(output_file, 'w') as f:
            f.write(instance_name + "\n")
            for route in self.routes:
                route_str = ' '.join(str(loc + 1) for loc in route.route)
                f.write(f"{route_str}\n")


if __name__ == '__main__':
    print(SCFPDPSolution(inst=SCFPDPInstance('10/test_instance_small.txt')))